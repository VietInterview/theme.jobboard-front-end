<?php

/* Include Custom Post Type for Job Application */

include_once get_template_directory() . '/includes/applications/posts.php';


/* Include All Custom Function for Job Application */

include_once get_template_directory() . '/includes/applications/app-functions.php';
